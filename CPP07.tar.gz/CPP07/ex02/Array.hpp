#ifndef ARRAY_HPP
#define ARRAY_HPP

#include <iostream>
#include <exception>

template <typename T>
class Array
{
private:
    T* _data;
    unsigned int _size;

public:
    // Default constructor
    Array() : _data(NULL), _size(0) {}

    // Param constructor
    Array(unsigned int n) : _data(new T[n]()), _size(n) {}

    // Copy constructor
    Array(const Array& other) : _data(NULL), _size(0)
    {
        *this = other;
    }

    // Assignment operator
    Array& operator=(const Array& other)
    {
        if (this != &other)
        {
            delete[] _data;
            _size = other._size;
            _data = new T[_size];

            for (unsigned int i = 0; i < _size; i++)
                _data[i] = other._data[i];
        }
        return *this;
    }

    // Destructor
    ~Array()
    {
        delete[] _data;
    }

    // operator[]
    T& operator[](unsigned int index)
    {
        if (index >= _size)
            throw std::exception();
        return _data[index];
    }

    // const version
    const T& operator[](unsigned int index) const
    {
        if (index >= _size)
            throw std::exception();
        return _data[index];
    }

    // size
    unsigned int size() const
    {
        return _size;
    }
};

#endif