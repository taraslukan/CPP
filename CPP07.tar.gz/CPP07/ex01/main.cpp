#include <iostream>
#include "iter.hpp"

void printInt(int const &x)
{
    std::cout << x << std::endl;
}

void increment(int &x)
{
    x++;
}

int main(void)
{
    int arr[] = {1, 2, 3, 4, 5};

    std::cout << "Original:" << std::endl;
    iter(arr, 5, printInt);

    iter(arr, 5, increment);

    std::cout << "After increment:" << std::endl;
    iter(arr, 5, printInt);

    return 0;
}