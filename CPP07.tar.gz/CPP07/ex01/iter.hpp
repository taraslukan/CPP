#ifndef ITER_HPP
#define ITER_HPP

#include <cstddef>

// NON-CONST VERSION
template <typename T>
void iter(T *array, std::size_t len, void (*f)(T &))
{
    for (std::size_t i = 0; i < len; i++)
        f(array[i]);
}

// CONST VERSION
template <typename T>
void iter(T const *array, std::size_t len, void (*f)(T const &))
{
    for (std::size_t i = 0; i < len; i++)
        f(array[i]);
}

#endif